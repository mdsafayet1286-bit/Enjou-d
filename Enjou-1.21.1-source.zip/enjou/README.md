# Enjou (Fabric, Minecraft 1.21.1)

Author: **Mr. Enjou**

## Build the jar
Requirements: **JDK 21** and **Gradle 8.8+** (or IntelliJ IDEA, which can import the project directly).

    gradle build            # or: gradle wrapper --gradle-version 8.8   then   ./gradlew build

The finished mod is `build/libs/enjou-1.0.0.jar` (ignore the `-sources` jar).
To test in-game: `gradle runClient`.

## Install
1. Install Fabric Loader for 1.21.1 and Fabric API.
2. Drop `enjou-1.0.0.jar` into your `mods` folder.

## What is in it
- **Raihan** - passive, 250 HP, drunk and smoking. Mumbles random lines in chat when you get close.
- **Sahil** - passive, 250 HP. Walks up to cows and feeds them (adults breed, babies grow faster) and chases baby villagers to scare them (no damage).
- **Anmol** - passive trader, 250 HP. Sells cat spawn eggs for gold / diamonds / netherite scrap and is the ONLY source of **Cat Armor Plating**.
- Raihan and Sahil fight each other on sight and trade slang in chat. Everyone else is left alone.
- **Cat Armor** - craft from 4 plating (2x2). Right-click your tamed cat to equip, sneak + empty hand to remove. Gives the cat +8 armor.
- **Grapes** - wild patches in jungle biomes; plant them like a crop (farmland or dirt). **Deshi Wine** = 4 grapes + sugar + glass bottle. Drinking it gives Drunk, Nausea and Slowness.
- **Tobacco** - wild patches in plains / savanna / meadow (for seeds). Smelt raw tobacco leaf in a furnace to dry it, then craft **Cigarettes** (2 dried leaves + paper = 4). Smoking one gives short Nausea and Slowness.
- Spawn eggs for all three are in the **Enjou** creative tab. They also spawn rarely in the overworld.

## Customise
- Skins: `src/main/resources/assets/enjou/textures/entity/*.png` (64x64 player skin layout).
- Dialogue: `src/main/java/com/enjou/util/Lines.java`.
- Trades: `AnmolEntity.fillRecipes()`.
- Health: `EnjouAttributes.HEALTH`.
