package com.enjou.client;

import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.util.Identifier;

/** Renders a mob with the player model and a custom 64x64 skin. Swap the PNGs to re-skin the characters. */
public class HumanoidMobRenderer<T extends MobEntity> extends BipedEntityRenderer<T, PlayerEntityModel<T>> {
    private final Identifier texture;

    public HumanoidMobRenderer(EntityRendererFactory.Context context, Identifier texture) {
        super(context, new PlayerEntityModel<>(context.getPart(EntityModelLayers.PLAYER), false), 0.5f);
        this.texture = texture;
    }

    @Override
    public Identifier getTexture(T entity) {
        return texture;
    }
}
