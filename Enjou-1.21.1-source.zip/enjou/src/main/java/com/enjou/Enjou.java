package com.enjou;

import com.enjou.event.CatArmorHandler;
import com.enjou.registry.ModBlocks;
import com.enjou.registry.ModEffects;
import com.enjou.registry.ModEntities;
import com.enjou.registry.ModItemGroups;
import com.enjou.registry.ModItems;
import com.enjou.world.ModWorldGen;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Enjou implements ModInitializer {
    public static final String MOD_ID = "enjou";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModBlocks.init();
        ModEffects.init();
        ModEntities.init();
        ModItems.init();
        ModItemGroups.init();
        ModWorldGen.init();
        CatArmorHandler.init();
        LOGGER.info("Enjou loaded. Raihan, Sahil and Anmol are out there somewhere.");
    }
}
