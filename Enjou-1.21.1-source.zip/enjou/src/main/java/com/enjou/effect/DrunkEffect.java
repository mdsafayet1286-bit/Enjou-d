package com.enjou.effect;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;

/** Makes you stumble around randomly. Combined with Nausea when drinking Deshi Wine. */
public class DrunkEffect extends StatusEffect {
    public DrunkEffect() {
        super(StatusEffectCategory.NEUTRAL, 0x9B3D6E);
    }

    @Override
    public boolean canApplyUpdateEffect(int duration, int amplifier) {
        return duration % 8 == 0;
    }

    @Override
    public boolean applyUpdateEffect(LivingEntity entity, int amplifier) {
        if (!entity.getWorld().isClient && entity.isOnGround()) {
            double push = 0.10 + 0.04 * amplifier;
            entity.addVelocity(
                (entity.getRandom().nextDouble() - 0.5) * 2 * push,
                0.0,
                (entity.getRandom().nextDouble() - 0.5) * 2 * push);
            entity.velocityModified = true;
        }
        return true;
    }
}
