package com.enjou.entity;

import com.enjou.util.ChatUtil;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/** Shared behaviour for Raihan and Sahil: passive towards everyone except each other. */
public abstract class EnjouMobEntity extends PathAwareEntity {
    private int fightChatCooldown = 40;

    protected EnjouMobEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
    }

    protected abstract String[] fightLines();

    @Override
    public void tickMovement() {
        super.tickMovement();
        if (!getWorld().isClient) {
            LivingEntity target = getTarget();
            if (target instanceof EnjouMobEntity && target.isAlive()) {
                if (--fightChatCooldown <= 0) {
                    ChatUtil.say(this, ChatUtil.pick(fightLines(), random), 48);
                    fightChatCooldown = 40 + random.nextInt(60);
                }
            }
        }
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_VILLAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_VILLAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_VILLAGER_DEATH;
    }
}
