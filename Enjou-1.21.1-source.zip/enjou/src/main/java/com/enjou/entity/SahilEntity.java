package com.enjou.entity;

import com.enjou.entity.goal.FeedCowGoal;
import com.enjou.entity.goal.ScareBabyVillagerGoal;
import com.enjou.util.Lines;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.World;

/** Sahil: loves cows (feeds and breeds them), enjoys scaring baby villagers. Hates Raihan. */
public class SahilEntity extends EnjouMobEntity {
    public SahilEntity(EntityType<? extends SahilEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return EnjouAttributes.fighter();
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(1, new MeleeAttackGoal(this, 1.1, true));
        goalSelector.add(2, new FeedCowGoal(this));
        goalSelector.add(3, new ScareBabyVillagerGoal(this));
        goalSelector.add(4, new WanderAroundFarGoal(this, 0.6));
        goalSelector.add(5, new LookAtEntityGoal(this, PlayerEntity.class, 6.0f));
        goalSelector.add(6, new LookAroundGoal(this));
        targetSelector.add(1, new ActiveTargetGoal<>(this, RaihanEntity.class, true));
    }

    @Override
    protected String[] fightLines() {
        return Lines.SAHIL_FIGHT;
    }

    @Override
    protected void initEquipment(Random random, LocalDifficulty difficulty) {
        equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.WHEAT));
        setEquipmentDropChance(EquipmentSlot.MAINHAND, 0.0f);
    }
}
