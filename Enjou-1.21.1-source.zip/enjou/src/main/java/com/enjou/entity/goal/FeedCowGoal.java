package com.enjou.entity.goal;

import com.enjou.entity.SahilEntity;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;

/** Sahil walks up to cows and feeds them: adults get "in love" (so they breed), babies grow faster. */
public class FeedCowGoal extends Goal {
    private static final int MAX_COWS_NEARBY = 12;

    private final SahilEntity sahil;
    private CowEntity cow;
    private int nextCheckAge;
    private int timeout;

    public FeedCowGoal(SahilEntity sahil) {
        this.sahil = sahil;
        setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    @Override
    public boolean canStart() {
        if (sahil.getTarget() != null || sahil.age < nextCheckAge) {
            return false;
        }
        nextCheckAge = sahil.age + 60 + sahil.getRandom().nextInt(40);
        List<CowEntity> cows = sahil.getWorld().getEntitiesByClass(
            CowEntity.class, sahil.getBoundingBox().expand(16, 4, 16), Entity::isAlive);
        boolean crowded = cows.size() > MAX_COWS_NEARBY;
        cow = null;
        double best = Double.MAX_VALUE;
        for (CowEntity c : cows) {
            boolean needsFood = c.isBaby() || (!crowded && c.getBreedingAge() == 0 && !c.isInLove());
            if (!needsFood) {
                continue;
            }
            double d = sahil.squaredDistanceTo(c);
            if (d < best) {
                best = d;
                cow = c;
            }
        }
        return cow != null;
    }

    @Override
    public boolean shouldContinue() {
        return cow != null && cow.isAlive() && sahil.getTarget() == null && timeout > 0;
    }

    @Override
    public void start() {
        timeout = 200;
        sahil.getNavigation().startMovingTo(cow, 1.0);
    }

    @Override
    public void stop() {
        cow = null;
        sahil.getNavigation().stop();
    }

    @Override
    public void tick() {
        timeout--;
        sahil.getLookControl().lookAt(cow, 30.0f, 30.0f);
        if (sahil.squaredDistanceTo(cow) < 4.0) {
            feed();
            cow = null;
            return;
        }
        if (sahil.age % 10 == 0) {
            sahil.getNavigation().startMovingTo(cow, 1.0);
        }
    }

    private void feed() {
        sahil.swingHand(Hand.MAIN_HAND);
        if (cow.isBaby()) {
            int age = -cow.getBreedingAge();
            cow.growUp((int) ((float) (age / 20) * 0.1f));
        } else {
            cow.lovePlayer(null);
        }
        sahil.getWorld().playSound(null, cow.getBlockPos(), SoundEvents.ENTITY_GENERIC_EAT, SoundCategory.NEUTRAL, 1.0f, 1.0f);
        if (sahil.getWorld() instanceof ServerWorld serverWorld) {
            serverWorld.spawnParticles(ParticleTypes.HAPPY_VILLAGER,
                cow.getX(), cow.getEyeY() + 0.3, cow.getZ(), 5, 0.3, 0.3, 0.3, 0.0);
        }
        nextCheckAge = sahil.age + 100 + sahil.getRandom().nextInt(60);
    }
}
