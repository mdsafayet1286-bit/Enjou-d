package com.enjou.entity.goal;

import com.enjou.entity.SahilEntity;
import com.enjou.util.ChatUtil;
import com.enjou.util.Lines;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;

/** Sahil chases baby villagers and jumps out at them for fun. Nobody gets hurt. */
public class ScareBabyVillagerGoal extends Goal {
    private final SahilEntity sahil;
    private VillagerEntity baby;
    private int nextCheckAge;
    private int timeout;

    public ScareBabyVillagerGoal(SahilEntity sahil) {
        this.sahil = sahil;
        setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    @Override
    public boolean canStart() {
        if (sahil.getTarget() != null || sahil.age < nextCheckAge) {
            return false;
        }
        nextCheckAge = sahil.age + 40 + sahil.getRandom().nextInt(40);
        List<VillagerEntity> babies = sahil.getWorld().getEntitiesByClass(
            VillagerEntity.class, sahil.getBoundingBox().expand(14, 4, 14), v -> v.isAlive() && v.isBaby());
        baby = null;
        double best = Double.MAX_VALUE;
        for (VillagerEntity v : babies) {
            double d = sahil.squaredDistanceTo(v);
            if (d < best) {
                best = d;
                baby = v;
            }
        }
        return baby != null;
    }

    @Override
    public boolean shouldContinue() {
        return baby != null && baby.isAlive() && sahil.getTarget() == null && timeout > 0;
    }

    @Override
    public void start() {
        timeout = 160;
        sahil.getNavigation().startMovingTo(baby, 1.2);
    }

    @Override
    public void stop() {
        baby = null;
        sahil.getNavigation().stop();
    }

    @Override
    public void tick() {
        timeout--;
        sahil.getLookControl().lookAt(baby, 30.0f, 30.0f);
        if (sahil.squaredDistanceTo(baby) < 9.0) {
            scare();
            baby = null;
            return;
        }
        if (sahil.age % 8 == 0) {
            sahil.getNavigation().startMovingTo(baby, 1.2);
        }
    }

    private void scare() {
        Vec3d away = baby.getPos().subtract(sahil.getPos()).multiply(1, 0, 1).normalize();
        baby.addVelocity(away.x * 0.5, 0.35, away.z * 0.5);
        baby.velocityModified = true;
        baby.playSound(SoundEvents.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
        if (sahil.getWorld() instanceof ServerWorld serverWorld) {
            serverWorld.spawnParticles(ParticleTypes.SPLASH,
                baby.getX(), baby.getEyeY() + 0.2, baby.getZ(), 8, 0.3, 0.2, 0.3, 0.1);
        }
        ChatUtil.say(sahil, ChatUtil.pick(Lines.SAHIL_SCARE, sahil.getRandom()), 32);
        nextCheckAge = sahil.age + 100 + sahil.getRandom().nextInt(100);
    }
}
