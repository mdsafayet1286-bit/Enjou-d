package com.enjou.event;

import com.enjou.registry.ModItems;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.passive.CatEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;

/**
 * Right-click your tamed cat with Cat Armor to equip it (stored in the cat's body armor slot).
 * Sneak + right-click with an empty hand to take it off again.
 */
public class CatArmorHandler {
    public static void init() {
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (player.isSpectator() || !(entity instanceof CatEntity cat)) {
                return ActionResult.PASS;
            }
            ItemStack held = player.getStackInHand(hand);
            boolean wearing = cat.getEquippedStack(EquipmentSlot.BODY).isOf(ModItems.CAT_ARMOR);

            if (held.isOf(ModItems.CAT_ARMOR) && !wearing && cat.isTamed() && cat.isOwner(player)) {
                if (!world.isClient) {
                    cat.equipStack(EquipmentSlot.BODY, held.copyWithCount(1));
                    cat.setEquipmentDropChance(EquipmentSlot.BODY, 1.0f);
                    held.decrementUnlessCreative(1, player);
                    world.playSound(null, cat.getBlockPos(), SoundEvents.ITEM_ARMOR_EQUIP_IRON.value(), SoundCategory.NEUTRAL, 1.0f, 1.2f);
                }
                return ActionResult.success(world.isClient);
            }

            if (player.isSneaking() && held.isEmpty() && wearing && cat.isOwner(player)) {
                if (!world.isClient) {
                    ItemStack armor = cat.getEquippedStack(EquipmentSlot.BODY).copy();
                    cat.equipStack(EquipmentSlot.BODY, ItemStack.EMPTY);
                    player.getInventory().offerOrDrop(armor);
                    world.playSound(null, cat.getBlockPos(), SoundEvents.ITEM_ARMOR_EQUIP_IRON.value(), SoundCategory.NEUTRAL, 1.0f, 0.8f);
                }
                return ActionResult.success(world.isClient);
            }
            return ActionResult.PASS;
        });
    }
}
