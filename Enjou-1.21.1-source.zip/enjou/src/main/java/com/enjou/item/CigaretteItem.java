package com.enjou.item;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Right-click to smoke one. It is not good for you: brief nausea and slowness. */
public class CigaretteItem extends Item {
    public CigaretteItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!world.isClient) {
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 100, 0));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 200, 0));
            world.playSound(null, player.getBlockPos(), SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.PLAYERS, 0.4f, 1.6f);
            if (world instanceof ServerWorld serverWorld) {
                Vec3d look = player.getRotationVec(1.0f);
                serverWorld.spawnParticles(ParticleTypes.LARGE_SMOKE,
                    player.getX() + look.x * 0.5, player.getEyeY() - 0.1, player.getZ() + look.z * 0.5,
                    6, 0.1, 0.1, 0.1, 0.01);
            }
        }
        player.getItemCooldownManager().set(this, 40);
        stack.decrementUnlessCreative(1, player);
        return TypedActionResult.success(stack, world.isClient());
    }
}
