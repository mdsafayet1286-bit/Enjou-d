package com.enjou.item;

import com.enjou.registry.ModEffects;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;

/** Deshi Wine: drink it to get drunk. */
public class WineItem extends Item {
    public WineItem(Settings settings) {
        super(settings);
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.DRINK;
    }

    // Two overloads so this works whichever signature the game calls (no @Override on purpose).
    public int getMaxUseTime(ItemStack stack) {
        return 32;
    }

    public int getMaxUseTime(ItemStack stack, LivingEntity user) {
        return 32;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        user.setCurrentHand(hand);
        return TypedActionResult.consume(user.getStackInHand(hand));
    }

    @Override
    public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
        super.finishUsing(stack, world, user);
        if (!world.isClient) {
            user.addStatusEffect(new StatusEffectInstance(ModEffects.DRUNK, 1800, 0));
            user.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 300, 0));
            user.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 600, 0));
        }
        if (user instanceof PlayerEntity player && player.getAbilities().creativeMode) {
            return stack;
        }
        stack.decrementUnlessCreative(1, user);
        if (stack.isEmpty()) {
            return new ItemStack(Items.GLASS_BOTTLE);
        }
        if (user instanceof PlayerEntity player) {
            player.getInventory().offerOrDrop(new ItemStack(Items.GLASS_BOTTLE));
        }
        return stack;
    }
}
