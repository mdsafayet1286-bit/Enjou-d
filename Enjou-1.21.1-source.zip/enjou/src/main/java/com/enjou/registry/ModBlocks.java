package com.enjou.registry;

import com.enjou.Enjou;
import com.enjou.block.GrapeVineBlock;
import com.enjou.block.TobaccoCropBlock;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModBlocks {
    public static final Block GRAPE_VINE = Registry.register(Registries.BLOCK, Enjou.id("grape_vine"),
        new GrapeVineBlock(AbstractBlock.Settings.copy(Blocks.WHEAT)));

    public static final Block TOBACCO_CROP = Registry.register(Registries.BLOCK, Enjou.id("tobacco_crop"),
        new TobaccoCropBlock(AbstractBlock.Settings.copy(Blocks.WHEAT)));

    public static void init() {}
}
