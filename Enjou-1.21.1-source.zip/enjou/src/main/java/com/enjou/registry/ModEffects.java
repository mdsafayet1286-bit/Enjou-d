package com.enjou.registry;

import com.enjou.Enjou;
import com.enjou.effect.DrunkEffect;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;

public class ModEffects {
    public static final RegistryEntry<StatusEffect> DRUNK =
        Registry.registerReference(Registries.STATUS_EFFECT, Enjou.id("drunk"), new DrunkEffect());

    public static void init() {}
}
